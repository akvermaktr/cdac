<?php
// $Id$
/**
 * @file
 * Wrapper for content viewable by anonymous users
 *
 * - $wrapper_id: The HTML id of the wrapper
 * - $content: The content
 *
 */
?>
<div id="<?php echo $wrapper_id; ?>-anonymous" class="cacheControlAnonymous"><?php echo $content; ?></div>

