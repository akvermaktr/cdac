Free. You are not allowed to sell the icons.
Icons by LazyCrazy
http://www.artdesigner.lv