<div id="demo" class="carousel slide" data-ride="carousel">
      <?php print $attachment_before; ?>
   
   
  <!-- The slideshow -->
  <div class="carousel-inner">
      
      <?php print $rows; ?>
 </div>
     <!-- Left and right controls -->
  <a class="carousel-control-prev" href="#demo" data-slide="prev">
    <span class="carousel-control-prev-icon"></span>
  </a>
  <a class="carousel-control-next" href="#demo" data-slide="next">
    <span class="carousel-control-next-icon"></span>
  </a>
  
  
</div>
    

