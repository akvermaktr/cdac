
<!-- For this when javascript Not working Showing Message -->
    <noscript>
    <div class="nos">
    <p>JavaScript must be enabled in order for you to use the Site in standard view. However, it seems JavaScript is either disabled or not supported by your browser. To use standard view, enable JavaScript by changing your browser options.</p>
    </div>
    </noscript>

<!-- End For this when javascript Not working Showing Message -->

<!-- Top Menu for GIGW -->

	<div class="container-fluid  top-menu-bg wow fadeInDown">
		<div class="container">
			<div class="time"><?php print render($page['clock']); ?></div>
                <ul class="top-menu" id="example1">
                    <li class="skip-to-m-h"><a href="#MainDiv" title="Skip to Main Content" tabindex="1">Skip to Main Content</a></li>
                    <li class="screen-reader-m-h" title="Screen Reader Access"><a href="/screenReaderAcess.aspx" title="Screen Reader Access">Screen Reader Access</a></li>
                    <li class="screen-reader-m-h"><a href="javascript:void(0);" title="Increase font size" onClick="set_font_size('increase')">A<sup>+</sup><span class="hidethis">Increase font size</span></a></li>
                    <li class="screen-reader-m-h"><a href="javascript:void(0);" title="Reset font size" onClick="set_font_size('')">A <span class="hidethis">Reset font size</span></a></li>
                    <li class="screen-reader-m-h"><a href="javascript:void(0);" title="Decrease font size" onClick="set_font_size('decrease')" >A<sup>-</sup> <span class="hidethis">Decrease font size</span></a></li>
                    <li class="hight-contrast screen-reader-m-h"><a href="javascript:void(0);" title="High Contrast" class="hc" onclick="chooseStyle('change', 60);">A <span class="hidethis">High Contrast</span></a></li>
                    <li class="normal screen-reader-m-h"><a href="javascript:void(0);" title="Normal" class="normal"  onclick="chooseStyle('style', 60);">A <span class="hidethis">Normal</span></a></li>  
                    <li class="blue-theme screen-reader-m-h"><a href="javascript:void(0);" title="blue" onclick="chooseStyle('style', 60);"><img src="<?php echo  $base_path . $directory ?>/images/blue-theme.png"></a></li>
                    <li class="green-theme screen-reader-m-h"><a href="javascript:void(0);" title="Green" onclick="chooseStyle('green', 60);"><img src="<?php echo  $base_path . $directory ?>/images/green.png"></a></li>
                    <li class="orange-theme screen-reader-m-h"><a href="javascript:void(0);" title="Orange" onclick="chooseStyle('orange', 60);"><img src="<?php echo  $base_path . $directory ?>/images/orange.png"></a></li>
                    <li><a href="#" title="हिंदी">हिंदी <span class="hidethis">Hindi Link:This will open in new window.</span></a></li> 
                </ul> 
		</div>
    </div>	
<!-- End Top Menu for GIGW -->

<!-- Start Logo Part -->
<div class="container-fluid" id="main-nav">
<div class="row">    
        <div class="container wow fadeInDown" data-wow-duration="1s" >
        	<div class="row">
	<div class="col-md-5">
						
					<div class=" logo">
					<img src="<?php echo  $base_path . $directory ?>/images/cyber-forensic-logo.png" title="Cyber Forensic" alt="cyber-forensic" class="img-responsive logo-img">
						<p class="logo-sub-heading">Resource Centre for</p>
						<h1><a href="#">Cyber Forensics - India</a></h1> 
					</div>
	</div>

    <div class="col-md-7 navigation-bg wow fadeInDown" data-wow-duration="2s">
				<nav>
                   <?php

 print render($page['navigation']); 
 
 ?>
				</nav>
				<div id="navigation">
   
<img src="<?php echo  $base_path . $directory ?>/images/cdac-logo.png" alt="CDAC" class="cdac-lo">
	</div>
	
	
</div>
</div>
				
                </div>
			</div>
<!-- Logo Part End -->


	
	
<!-- Start Slider -->      

  <?php print render($page['slideshow']); ?>


<div class="clearfix"> </div>
<!-- End Slider -->
<!-- Strart Menu Part -->    
 	<div class="container tt">
		<div class="row">
        <div class="col-md-12">
			<div class="ticker1 modern-ticker mt-round mt-scroll">
				<div class="latest-update"> <i class="fa fa-bell"></i> Announcement</div>
					<div class="mt-news">
						<ul>
                       <li><a href="#" target="_self" title="News">Augmentation of telemetry, computing and communication facilities.</a></li>
                       <li><a href="#" target="_self" title="News">System studies, planning and contingency analysis.</a></li>
                       <li><a href="#" target="_self" title="News">Computation of energy despatch and drawal values using SEMs.</a></li>
                       <li><a href="#" target="_self" title="News">To ensure the integrated operation of the power system grid in the region. </a></li>
                       <li><a href="#" target="_self" title="News">Taking Christmas Parties now.</a></li></ul>
					</div>
          			<div class="mt-controls">
                    <a href="#mt-pause" class="mt-play mt-pause" title="Pause"><span class="hidethis">Pause</span></a>
              </div>
            </div>
    	</div>
        </div>
    </div>
	
<!-- About Us Part --> 
  <div class="container about-us-section">
	<div class="row">
    <div class="col-md-12 text-center">
    <h2>Resource Centre for Cyber Forensics (RCCF) </h2>
<p>is a pioneering institute, pursuing research activities in the area of Cyber Forensics. The centre was dedicated to the nation by the then Honorable union minister in August 2008.</p>
		</div>
    </div>
    
    
    <div class="row">
        <div class="col-md-12">
            <div class="row">
            	<div class="col-md-2">
            		<div class="about-us-icons-part abt-bg">
					<a href="#">
						<img src="<?php echo  $base_path . $directory ?>/images/memory-forensic.png" alt="Memory Forensic" title="Memory Forensic" />
                		<h3>Memory Forensics</h3>
                		</a>
            		</div>
            	</div>
            
            <div class="col-md-2">
                <div class="about-us-icons-part abt-bg1">
            		<a href="#">
                		<img src="<?php echo  $base_path . $directory ?>/images/live-internet.png" alt="Live & Internet Forensics" title="Live & Internet Forensics" />
                		<h3>Live & Internet Forensics</h3>
                		</a>
            		</div>
            	</div>
            
            <div class="col-md-2">
            	<div class="about-us-icons-part abt-bg2">
            		<a href="#">
                		<img src="<?php echo  $base_path . $directory ?>/images/multimedia.png" alt="Multimedia" title="Multimedia" />
                		<h3>Multimedia Forensics</h3>
                		</a>
            </div>
        		</div>
				
				<div class="col-md-2">
            	<div class="about-us-icons-part abt-bg3">
            		<a href="#">
                		<img src="<?php echo  $base_path . $directory ?>/images/disk-forensic.png" alt="Disk Forensics" title="Disk Forensics" />
                		<h3>Disk Forensics</h3>
                		</a>
            </div>
        		</div>
				
				
				<div class="col-md-2">
            	<div class="about-us-icons-part abt-bg4">
            		<a href="#">
                		<img src="<?php echo  $base_path . $directory ?>/images/network.png" alt="Live & Internet Forensics" title="Live & Internet Forensics" />
                		<h3>Network Forensics</h3>
                		</a>
            </div>
        		</div>
				
				
				<div class="col-md-2">
            	<div class="about-us-icons-part abt-bg5">
            		<a href="#">
                		<img src="<?php echo  $base_path . $directory ?>/images/mobile-device.png" alt="Live & Internet Forensics" title="Live & Internet Forensics" />>
                		<h3>Mobile Device Forensics</h3>
                		</a>		
            </div>
        		</div>
                
                
                
        	</div>
		</div>
	</div>
    </div>
	
<!-- End About Us Part -->

<!-- start body Part -->
	<div class="container-fluid body-background">
	<div class="row">      
	<div class="container">
		<div class="row">
			<div class="col-md-7">
			<div class="services">
			<img src="<?php echo  $base_path . $directory ?>/images/providing-solutions.png" alt="Live & Internet Forensics" title="Live & Internet Forensics" class="float-right" />
			<h3>Providing Solution</h3>
			<p>Our research team works in various areas of cyber forensics such as Disk Forensics...</p>
			<a href="#" class="btn btn-light">Read more...</a>
			</div>
			</div>
			
			<div class="col-md-5">
			<div class="services services-bg1">
			<img src="<?php echo  $base_path . $directory ?>/images/procedure.png" alt="Live & Internet Forensics" title="Live & Internet Forensics" class="float-right" />
			<h3>Procedure</h3>
			<p>When a compromise of security or a ....</p>
			<a href="#" class="btn btn-light">Read more...</a>
			</div>
			</div>
			
			
			<div class="col-md-5">
			<div class="services services-bg1">
			<img src="<?php echo  $base_path . $directory ?>/images/white-papper.png" alt="Live & Internet Forensics" title="Live & Internet Forensics" class="float-right img-fluid" />
			<h3>Providing Solution</h3>
			<p>Our research team works in various areas...</p>
			<a href="#" class="btn btn-light">Read more...</a>
			</div>
			
			</div>
			
			
			<div class="col-md-7">
			<div class="services services-bg2">
			<i class="fa fa-picture-o float-right" aria-hidden="true"></i>
			<h3>Photo Gallery</h3>
			<p>Centre for Development of Advanced Computing (C-DAC) is the premier R&D ...</p>
			<a href="#" class="btn btn-light">Read more...</a>
			</div>
			</div>
		</div>
	</div>
	</div>
	</div>
	
<!-- End body Part -->

<!-- End Our Programs Section -->

<!-- Start Our Project Section -->


    </div>
<!-- End Our Project Section -->

    </section>
          
   

	<!-- Footer part --> 
 <div class="container-fluid wow slideInRight footer-slider-bg">
 <div class="container">
 <div class="row">
 <div class=" col-md-12">
 <div class="our-users">Our Users</div>
				<div class=" ticker modern-ticker modern-ticker1 mt-round mt-scroll">
					<div class="mt-news">
						<ul class="footer-logo">
							
                                                 <li><a href="http://www.cyberforensics.in" target="_blank" onclick="return confirm('This link will take you to an external website.')"><img src="<?php echo  $base_path . $directory ?>/upload_files/fldgi36.jpg" alt="Kerala Police" title="Kerala Police" class="img-responsive"></a></li>
                                        <li><a href="http://www.cyberforensics.in" target="_blank" onclick="return confirm('This link will take you to an external website.')"><img src="<?php echo  $base_path . $directory ?>/upload_files/6rmf7is.jpg" alt="Central Bureau of Investigation" title="Central Bureau of Investigation" class="img-responsive"></a></li>
                                        <li><a href="http://www.cyberforensics.in" target="_blank" onclick="return confirm('This link will take you to an external website.')"><img src="<?php echo  $base_path . $directory ?>/upload_files/rsnygwt.jpg" alt="Sardar Vallabhbhai Patel National Police Academy" title="Sardar Vallabhbhai Patel National Police Academy" class="img-responsive"></a></li>
                                        <li><a href="http://www.cyberforensics.in" target="_blank" onclick="return confirm('This link will take you to an external website.')"><img src="<?php echo  $base_path . $directory ?>/upload_files/oin8bjl.jpg" alt="Directorate of Forensic Science Laboratory" title="Directorate of Forensic Science Laboratory" class="img-responsive"></a></li>
                                        <li><a href="http://www.cyberforensics.in" target="_blank" onclick="return confirm('This link will take you to an external website.')"><img src="<?php echo  $base_path . $directory ?>/upload_files/8g9g1mt.jpg" alt="Indian Institute of Science" title="Indian Institute of Science" class="img-responsive"></a></li>
                       


                           
			</ul>

	  </div>

                    <div class="mt-controls mt-controls1">

						<a title="prev" class="mt-prev" href="#modern-ticker"></a>

						<a title="next" class="mt-next mt-next1" href="#modern-ticker"></a>

				      </div>

				</div>

    </div> 
  </div>
  </div>
  </div>

  <!-- Footer part --> 
<footer>

<div class="footer wow fadeInUp">
<div class="container">
<div class="row">
<div class="col-md-3">
        <?php print render($page['footer1']); ?>   
        </div>
        
        <div class="col-md-3">
         <?php print render($page['footer2']); ?>   
        </div>  
        
        <div class="col-md-3">
         <?php print render($page['footer3']); ?> 
           
        </div>
        
        <div class="col-md-3">
         <?php print render($page['footer4']); ?>
           
        </div>
		</div>
</div>
</div>
<a id="back2Top" title="Back to top" href="#">&#10148;</a>
<section class="copy-right">
<div class="container">
<div class="row">
<div class="col-md-3">
<div class="last-update">Last Updated On: 24/02/2019</div>
</div>

<div class="col-md-6 text-center">C-DAC Thiruvananthapuram. All rights reserved. </div>
<div class="col-md-3 text-right">
<div class="visitor-count">Visitor Counter: 37945</div>
</div>
</div>
</div>
</section>
 </footer>



<script>
window.onscroll = function() {myFunction()};

var navbar = document.getElementById("main-nav");
var sticky = navbar.offsetTop;

function myFunction() {
    /*
  if (window.pageYOffset >= sticky) {
    navbar.classList.add("sticky")
  } else {
    navbar.classList.remove("sticky");
  }*/
}
</script>
	<!-- Footer part -->  
    

  <script>
  /*Scroll to top when arrow up clicked BEGIN*/
$(window).scroll(function() {
    var height = $(window).scrollTop();
    if (height > 100) {
        $('#back2Top').fadeIn();
    } else {
        $('#back2Top').fadeOut();
    }
});
$(document).ready(function() {
    $("#back2Top").click(function(event) {
        event.preventDefault();
        $("html, body").animate({ scrollTop: 0 }, "slow");
        return false;
    });

});
 /*Scroll to top when arrow up clicked END*/
  
  </script>
